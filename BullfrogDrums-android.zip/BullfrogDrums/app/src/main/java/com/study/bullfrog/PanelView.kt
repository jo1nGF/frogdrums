package com.study.bullfrog

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private fun k(h: Long): Int = h.toInt()
private fun mix(a: Int, b: Int, t: Float): Int {
    val u = 1f - t
    return Color.rgb(
        (Color.red(a) * u + Color.red(b) * t).toInt(),
        (Color.green(a) * u + Color.green(b) * t).toInt(),
        (Color.blue(a) * u + Color.blue(b) * t).toInt()
    )
}

private val TOP_LABELS = arrayOf(
    "SHIFT", "TRACK", "CLEAR", "LAST STEP", "SHUFFLE", "MUTE", "PATT", "KIT", "SAMPLE", "START",
    "END", "REVERSE", "LOOP", "ACCENT", "RATCHET", "ODDS/PROB", "BAR1", "BAR2", "BAR3", "BAR4"
)

// Secondary (SHIFT) functions printed below the buttons: name, first button, last button, pill width
private val SEC_NAMES = arrayOf("TAP", "SCALE", "DIRECT", "SOLO", "RELOAD", "uTIME", "ROLL", "BANKS")
private val SEC_A = intArrayOf(1, 3, 4, 5, 6, 13, 14, 16)
private val SEC_B = intArrayOf(1, 3, 4, 5, 7, 13, 14, 19)
private val SEC_W = floatArrayOf(52f, 54f, 54f, 52f, 112f, 52f, 52f, 86f)

// 7-segment glyphs: a=1 b=2 c=4 d=8 e=16 f=32 g=64
private fun glyph(ch: Char): Int = when (ch.uppercaseChar()) {
    '0', 'O' -> 63
    '1' -> 6
    '2', 'Z' -> 91
    '3' -> 79
    '4' -> 102
    '5', 'S' -> 109
    '6' -> 125
    '7' -> 7
    '8' -> 127
    '9' -> 111
    'A' -> 119
    'B' -> 124
    'C' -> 57
    'D' -> 94
    'E' -> 121
    'F' -> 113
    'G' -> 61
    'H', 'K' -> 118
    'I' -> 48
    'J' -> 30
    'L' -> 56
    'M' -> 55
    'N' -> 84
    'P' -> 115
    'Q' -> 103
    'R' -> 80
    'T' -> 120
    'U', 'V', 'W' -> 62
    'Y' -> 110
    '-' -> 64
    '_' -> 8
    '#' -> 99
    else -> 0
}

/**
 * Geometry of one panel layout. All coordinates are "design units"; the view scales the
 * design to the screen. Two layouts exist: the original landscape photo layout and a
 * portrait re-flow (same controls, stacked vertically for phones held upright).
 */
private class Lay {
    var portrait = false
    var dw = 0f
    var dh = 0f
    var ox = 0f
    var oy = 0f
    var margin = 36f

    val lvX = FloatArray(7)
    val lvY = FloatArray(7)
    val paX = FloatArray(7)
    val paY = FloatArray(7)
    var ks = 1f
    var ledDy = 63f
    var lblSize = 13.5f
    var lblDyLv = 52f
    var lblDyPa = 54f
    var volX = 0f
    var volY = 0f
    var encX = 0f
    var encY = 0f
    var ks2 = 1f
    var knobHit = 50f

    val trX = FloatArray(3)
    val trY = FloatArray(3)
    var trH = 34f

    val fx = FloatArray(20)
    val fy = FloatArray(20)
    var padH = 15f
    var fHitW = 31f
    var fHitH = 31f
    var topLbl = 13f
    var secScale = 1f

    val stX = FloatArray(16)
    val stY = FloatArray(16)
    var stHw = 34f
    var stHh = 33f

    var frogX = 355f
    var frogY = 825f
    var frogS = 1f
    var dispX = 535f
    var dispY = 826f
    var dispS = 1f
    var logoX = 1555f
    var logoY = 806f
    var logoS = 1f

    var face = floatArrayOf(0f, 0f, 0f, 0f)
    var capA = floatArrayOf(0f, 0f, 0f, 0f)
    var capB = floatArrayOf(0f, 0f, 0f, 0f)
    var shadow = floatArrayOf(0f, 0f, 0f, 0f)
    var jackY = 0f
    var jackX = floatArrayOf()
    var switchX = 0f
    var panels = arrayOf<FloatArray>()
    var panelColors = intArrayOf()
    var strips = arrayOf<FloatArray>()

    var rotX = 0f
    var rotY = 0f
    var rotR = 20f
}

private val KX_L = floatArrayOf(672f, 795f, 920f, 1044f, 1167f, 1292f, 1416f)
private val FX_L = floatArrayOf(
    245f, 309f, 373f, 437f, 500f, 564f, 649f, 713f, 799f, 863f,
    927f, 991f, 1055f, 1140f, 1204f, 1267f, 1352f, 1416f, 1480f, 1544f
)

/** Original layout: coordinates measured on the reference photo of the front panel. */
private fun landscapeLayout(): Lay {
    val l = Lay()
    l.portrait = false
    l.dw = 1587f; l.dh = 708f; l.ox = 103f; l.oy = 682f; l.margin = 36f
    for (i in 0 until 7) { l.lvX[i] = KX_L[i]; l.lvY[i] = 820f; l.paX[i] = KX_L[i]; l.paY[i] = 990f }
    l.ks = 1f; l.ledDy = 63f; l.lblSize = 13.5f; l.lblDyLv = 52f; l.lblDyPa = 54f
    l.volX = 1565f; l.volY = 990f; l.encX = 533f; l.encY = 990f; l.ks2 = 1f; l.knobHit = 50f
    val tx = floatArrayOf(242f, 329f, 417f)
    for (n in 0 until 3) { l.trX[n] = tx[n]; l.trY[n] = 1009f }
    l.trH = 34f
    for (id in 0 until 20) { l.fx[id] = FX_L[id]; l.fy[id] = 1135f }
    l.padH = 15f; l.fHitW = 31f; l.fHitH = 31f; l.topLbl = 13f; l.secScale = 1f
    for (i in 0 until 16) { l.stX[i] = 243f + 87f * i; l.stY[i] = 1257f }
    l.stHw = 34f; l.stHh = 33f
    l.frogX = 355f; l.frogY = 825f; l.frogS = 1f
    l.dispX = 535f; l.dispY = 826f; l.dispS = 1f
    l.logoX = 1555f; l.logoY = 806f; l.logoS = 1f
    l.face = floatArrayOf(150f, 695f, 1642f, 1375f)
    l.capA = floatArrayOf(103f, 682f, 176f, 1390f)
    l.capB = floatArrayOf(1617f, 682f, 1690f, 1390f)
    l.shadow = floatArrayOf(120f, 712f, 1676f, 1404f)
    l.jackY = 680f; l.jackX = floatArrayOf(1155f, 1275f, 1365f); l.switchX = 1568f
    l.panels = arrayOf(
        floatArrayOf(609f, 748f, 1467f, 897f),
        floatArrayOf(609f, 913f, 1467f, 1061f),
        floatArrayOf(183f, 1080f, 1610f, 1316f)
    )
    l.panelColors = intArrayOf(k(0xFFC9C9C9), k(0xFFC9C9C9), k(0xFFC4C4C4))
    l.strips = arrayOf(floatArrayOf(207f, 1095f, 1585f, 1115f))
    l.rotX = 139f; l.rotY = 742f; l.rotR = 24f
    return l
}

/**
 * Portrait layout (720 x 1560): header (frog / display / logo), transport + DATA + VOLUME,
 * the two knob rows, the 20 function buttons in two rows and the 16 step keys as a 4 x 4 grid
 * (each row = one group of four keys, keeping the dark/light grouping of the hardware).
 */
private fun portraitLayout(): Lay {
    val l = Lay()
    l.portrait = true
    l.dw = 720f; l.dh = 1560f; l.ox = 0f; l.oy = 0f; l.margin = 12f
    for (i in 0 until 7) {
        val x = 78f + 94f * i
        l.lvX[i] = x; l.lvY[i] = 452f; l.paX[i] = x; l.paY[i] = 612f
    }
    l.ks = 0.85f; l.ledDy = 55f; l.lblSize = 12.5f; l.lblDyLv = 47f; l.lblDyPa = 47f
    l.volX = 592f; l.volY = 300f; l.encX = 430f; l.encY = 300f; l.ks2 = 0.95f; l.knobHit = 46f
    val tx = floatArrayOf(78f, 172f, 266f)
    for (n in 0 until 3) { l.trX[n] = tx[n]; l.trY[n] = 300f }
    l.trH = 32f
    for (id in 0 until 20) {
        l.fx[id] = 63f + 66f * (id % 10)
        l.fy[id] = if (id < 10) 748f else 848f
    }
    l.padH = 18f; l.fHitW = 32f; l.fHitH = 38f; l.topLbl = 11.5f; l.secScale = 0.92f
    for (i in 0 until 16) {
        l.stX[i] = 120f + 160f * (i % 4)
        l.stY[i] = 996f + 132f * (i / 4)
    }
    l.stHw = 62f; l.stHh = 40f
    l.frogX = 130f; l.frogY = 150f; l.frogS = 0.8f
    l.dispX = 385f; l.dispY = 150f; l.dispS = 1.25f
    l.logoX = 600f; l.logoY = 140f; l.logoS = 0.8f
    l.face = floatArrayOf(12f, 42f, 708f, 1518f)
    l.capA = floatArrayOf(6f, 14f, 714f, 70f)
    l.capB = floatArrayOf(6f, 1490f, 714f, 1546f)
    l.shadow = floatArrayOf(14f, 52f, 716f, 1540f)
    l.jackY = 1f; l.jackX = floatArrayOf(440f, 520f, 590f); l.switchX = 668f
    l.panels = arrayOf(
        floatArrayOf(22f, 382f, 698f, 530f),
        floatArrayOf(22f, 542f, 698f, 674f),
        floatArrayOf(22f, 692f, 698f, 905f),
        floatArrayOf(22f, 916f, 698f, 1462f)
    )
    l.panelColors = intArrayOf(k(0xFFC9C9C9), k(0xFFC9C9C9), k(0xFFC4C4C4), k(0xFFC4C4C4))
    l.strips = arrayOf(floatArrayOf(36f, 708f, 684f, 728f), floatArrayOf(36f, 808f, 684f, 828f))
    l.rotX = 48f; l.rotY = 42f; l.rotR = 20f
    return l
}

class PanelView(ctx: Context, private val ctl: Controller) : View(ctx) {

    /** Set by the Activity: switches between portrait and landscape. */
    var onToggleOrientation: (() -> Unit)? = null

    private val landscape = landscapeLayout()
    private val portrait = portraitLayout()
    private var lay: Lay = portrait

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val path = Path()
    private var bmp: Bitmap? = null
    private var sc = 1f
    private var offX = 0f
    private var offY = 0f
    private var encAngle = 0f
    private var latch = false
    private val latched = HashSet<Int>()

    private class Ptr(val kind: Int, val id: Int, val t0: Long, var lx: Float, var ly: Float) {
        var moved = 0f
        var acc = 0f
    }

    private val ptrs = HashMap<Int, Ptr>()

    private companion object {
        const val K_NONE = 0
        const val K_BTN = 1
        const val K_STEP = 2
        const val K_PARAM = 3
        const val K_LEVEL = 4
        const val K_VOL = 5
        const val K_ENC = 6
        const val K_FROG = 7
        const val K_ROT = 8
    }

    // ------------------------------------------------------------------ drawing helpers

    private fun fill(color: Int) {
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = color
    }

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        fill(color)
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
    }

    private fun rrStroke(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int, w: Float) {
        paint.style = Paint.Style.STROKE
        paint.shader = null
        paint.strokeWidth = w
        paint.color = color
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
        paint.style = Paint.Style.FILL
    }

    private fun grad(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, top: Int, bottom: Int) {
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, t, 0f, b, top, bottom, Shader.TileMode.CLAMP)
        rect.set(l, t, r, b)
        c.drawRoundRect(rect, rad, rad, paint)
        paint.shader = null
    }

    private fun circ(c: Canvas, x: Float, y: Float, r: Float, color: Int) {
        fill(color)
        c.drawCircle(x, y, r, paint)
    }

    private fun txt(c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean) {
        paint.style = Paint.Style.FILL
        paint.shader = null
        paint.color = color
        paint.textSize = size
        paint.textAlign = Paint.Align.CENTER
        paint.typeface = if (bold) Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD) else Typeface.SANS_SERIF
        c.drawText(s, x, y, paint)
    }

    // ------------------------------------------------------------------ static layer

    private fun drawCap(c: Canvas, r4: FloatArray, seed: Long) {
        val l = r4[0]
        val t = r4[1]
        val r = r4[2]
        val b = r4[3]
        rr(c, l, t, r, b, 9f, k(0xFF161616))
        val rnd = Random(seed)
        val n = ((r - l) * (b - t) / 27f).toInt()
        for (q in 0 until n) {
            val x = l + rnd.nextFloat() * (r - l)
            val y = t + rnd.nextFloat() * (b - t)
            val g = 45 + rnd.nextInt(80)
            circ(c, x, y, 0.7f + rnd.nextFloat() * 1.3f, Color.argb(150, g, g, g))
        }
    }

    private fun drawDots(c: Canvas, cx: Float, cy: Float) {
        for (n in 0..10) {
            val a = (-135.0 + 27.0 * n) * PI / 180.0
            val x = cx + 51f * sin(a).toFloat()
            val y = cy - 51f * cos(a).toFloat()
            circ(c, x, y, if (n == 5) 3.1f else 2.4f, k(0xFF2B2B2B))
        }
    }

    private fun drawKnobBody(c: Canvas, cx: Float, cy: Float, capColor: Int) {
        circ(c, cx + 2f, cy + 5f, 47f, k(0x33000000))
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, 44f,
            intArrayOf(k(0xFFB4B4B4), k(0xFF9A9A9A), k(0xFF707070)),
            floatArrayOf(0.7f, 0.9f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, 43f, paint)
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1.3f
        paint.color = k(0x66404040)
        for (n in 0 until 54) {
            val a = n * 2.0 * PI / 54.0
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(cx + 38f * ca, cy + 38f * sa, cx + 43f * ca, cy + 43f * sa, paint)
        }
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx - 10f, cy - 12f, 46f, mix(capColor, Color.WHITE, 0.22f), capColor, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, 35f, paint)
        paint.shader = null
    }

    /** Knob (dots + body) drawn at (x, y) with scale s. */
    private fun knobAt(c: Canvas, x: Float, y: Float, s: Float, capColor: Int, dots: Boolean) {
        c.save()
        c.translate(x, y)
        c.scale(s, s)
        if (dots) drawDots(c, 0f, 0f)
        drawKnobBody(c, 0f, 0f, capColor)
        c.restore()
    }

    private fun drawFrog(c: Canvas) {
        val fc = k(0xFFC2C2C2)
        val face = k(0xFFD9D9D9)
        circ(c, 313f, 748f, 29f, fc)
        circ(c, 398f, 748f, 29f, fc)
        circ(c, 313f, 751f, 14f, face)
        circ(c, 398f, 751f, 14f, face)
        fill(fc)
        rect.set(266f, 758f, 444f, 905f)
        c.drawOval(rect, paint)
        circ(c, 280f, 860f, 17f, fc)
        circ(c, 432f, 860f, 17f, fc)
        rect.set(262f, 890f, 330f, 920f); c.drawOval(rect, paint)
        rect.set(380f, 890f, 448f, 920f); c.drawOval(rect, paint)
        for (n in 0 until 3) {
            circ(c, 262f + n * 9f, 914f, 6f, fc)
            circ(c, 448f - n * 9f, 914f, 6f, fc)
        }
        // speaker grille: eight rounded bars following an ellipse envelope + two side nubs
        for (n in 0 until 8) {
            val x = 303f + n * 16.2f
            val u = (x - 358f) / 64f
            var hh = 47f * sqrt(maxOf(0.05f, 1f - u * u))
            if (hh < 12f) hh = 12f
            rr(c, x - 4.6f, 825f - hh, x + 4.6f, 825f + hh, 4.6f, k(0xFF151515))
        }
        rr(c, 283f, 811f, 292f, 839f, 4.5f, k(0xFF151515))
        rr(c, 425f, 811f, 434f, 839f, 4.5f, k(0xFF151515))
    }

    private fun drawStatic(c: Canvas, l: Lay) {
        c.drawColor(k(0xFF1B1C1E))
        // device body
        rr(c, l.shadow[0], l.shadow[1], l.shadow[2], l.shadow[3], 26f, k(0x55000000))
        grad(c, l.face[0], l.face[1], l.face[2], l.face[3], 12f, k(0xFFE2E2E2), k(0xFFD2D2D2))
        rrStroke(c, l.face[0] + 1f, l.face[1] + 1f, l.face[2] - 1f, l.face[3] - 1f, 12f, k(0x55FFFFFF), 2f)
        drawCap(c, l.capA, 11L)
        drawCap(c, l.capB, 12L)
        // jacks and power switch
        for (x in l.jackX) {
            rr(c, x - 25f, l.jackY, x + 25f, l.jackY + 17f, 4f, k(0xFF8E8E8E))
            rr(c, x - 17f, l.jackY + 3f, x + 17f, l.jackY + 16f, 3f, k(0xFFCFCFCF))
        }
        rr(c, l.switchX - 24f, l.jackY - 2f, l.switchX + 28f, l.jackY + 16f, 3f, k(0xFF0E0E0E))
        circ(c, l.switchX, l.jackY + 6f, 2.6f, k(0xFFE0E0E0))

        // sections
        for (n in l.panels.indices) {
            val p = l.panels[n]
            rr(c, p[0], p[1], p[2], p[3], 14f, l.panelColors[n])
            rrStroke(c, p[0], p[1], p[2], p[3], 14f, k(0x22000000), 1.5f)
        }

        // frog + speaker
        c.save()
        c.translate(l.frogX, l.frogY)
        c.scale(l.frogS, l.frogS)
        c.translate(-355f, -825f)
        drawFrog(c)
        c.restore()

        // display bezel
        val hw = 57f * l.dispS
        val hh = 26f * l.dispS
        rr(c, l.dispX - hw, l.dispY - hh, l.dispX + hw, l.dispY + hh, 6f * l.dispS, k(0xFF171414))
        rrStroke(c, l.dispX - hw, l.dispY - hh, l.dispX + hw, l.dispY + hh, 6f * l.dispS, k(0x44FFFFFF), 1.5f)

        // logo
        c.save()
        c.translate(l.logoX, l.logoY)
        c.scale(l.logoS, l.logoS)
        circ(c, -7f, 0f, 72f, k(0xFFC8C8C8))
        circ(c, 7f, 0f, 64f, k(0xFF1D1D1D))
        txt(c, "bull", 5f, 0f, 46f, Color.WHITE, true)
        txt(c, "frog", 5f, 42f, 48f, Color.WHITE, true)
        txt(c, "DRUMS", -5f, 87f, 31f, k(0xFFBDBDBD), true)
        c.restore()

        // knob labels, knob bodies, LED wells
        val ink = k(0xFF2A2A2A)
        val black = k(0xFF1C1C1C)
        val caps = intArrayOf(k(0xFF3576A0), k(0xFFB93B3B), k(0xFFCFB346), k(0xFF317948), k(0xFF347B4A), k(0xFFB93B3B), k(0xFFB93B3B))
        for (i in 0 until 7) {
            txt(c, "LEVEL" + (i + 1), l.lvX[i], l.lvY[i] - l.lblDyLv, l.lblSize, ink, false)
            txt(c, Prm.NAMES[i], l.paX[i], l.paY[i] - l.lblDyPa, l.lblSize, ink, false)
            knobAt(c, l.lvX[i], l.lvY[i], l.ks, black, true)
            knobAt(c, l.paX[i], l.paY[i], l.ks, caps[i], true)
            val ly = l.lvY[i] + l.ledDy
            circ(c, l.lvX[i], ly, 12f, k(0xFF1A1214))
            rrStroke(c, l.lvX[i] - 12f, ly - 12f, l.lvX[i] + 12f, ly + 12f, 12f, k(0x66FFFFFF), 1.6f)
        }
        txt(c, "VOLUME", l.volX, l.volY - l.lblDyPa * l.ks2, l.lblSize, ink, false)
        txt(c, "DATA", l.encX, l.encY - l.lblDyPa * l.ks2, l.lblSize, ink, false)
        knobAt(c, l.volX, l.volY, l.ks2, black, true)
        knobAt(c, l.encX, l.encY, l.ks2, black, false)
        val names = arrayOf("PLAY/PAUSE", "STOP", "REC")
        for (n in 0 until 3) txt(c, names[n], l.trX[n], l.trY[n] - (l.trH + 20f), l.lblSize, ink, false)

        // function panel: label strips, labels, wells, secondary pills and brackets
        for (s in l.strips) rr(c, s[0], s[1], s[2], s[3], 10f, k(0xFFDADADA))
        for (id in 0 until 20) {
            txt(c, TOP_LABELS[id], l.fx[id], l.fy[id] - 25f, l.topLbl, ink, false)
            rr(c, l.fx[id] - l.padH - 2f, l.fy[id] - l.padH - 2f, l.fx[id] + l.padH + 2f, l.fy[id] + l.padH + 2f, 4f, k(0x33000000))
        }
        val br = k(0xFFE9E9E9)
        val pill = k(0xFFDEDEDE)
        for (n in 0 until 8) {
            val a = SEC_A[n]
            val b = SEC_B[n]
            val y = l.fy[a]
            val cx = (l.fx[a] + l.fx[b]) / 2f
            rrStroke(c, l.fx[a] - 22f, y - 11f, l.fx[b] + 22f, y + 33f, 8f, br, 1.8f)
            val w = SEC_W[n] * l.secScale
            rr(c, cx - w / 2f, y + 21f, cx + w / 2f, y + 41f, 10f, pill)
            txt(c, SEC_NAMES[n], cx, y + 36f, l.topLbl - 1f, ink, false)
        }

        // step key groups (one group = four keys)
        for (g in 0 until 4) {
            var minX = l.stX[g * 4]
            var maxX = minX
            for (q in 0 until 4) {
                val x = l.stX[g * 4 + q]
                if (x < minX) minX = x
                if (x > maxX) maxX = x
            }
            val y = l.stY[g * 4]
            val gl = minX - l.stHw - 10f
            val gr = maxX + l.stHw + 10f
            val gt = y - l.stHh - 28f
            val gb = y + l.stHh + 14f
            rrStroke(c, gl, gt, gr, gb, 10f, k(0xFFE9E9E9), 1.8f)
            rr(c, gl + 1f, gt - 1f, gr - 1f, gt + 16f, 8f, k(0xFFDADADA))
            for (q in 0 until 4) txt(c, "" + (g * 4 + q + 1), l.stX[g * 4 + q], gt + 12f, 12f, ink, false)
        }
    }

    // ------------------------------------------------------------------ dynamic layer

    private fun drawSeg(c: Canvas, ch: Int, cx: Float, cy: Float, on: Int, off: Int) {
        val w = 19f
        val h = 36f
        val t = 4.8f
        c.save()
        c.translate(cx, cy)
        c.skew(-0.17f, 0f)
        for (s in 0 until 7) {
            val lit = (ch and (1 shl s)) != 0
            path.reset()
            when (s) {
                0 -> hSeg(-w / 2f, w / 2f, -h / 2f, t)
                6 -> hSeg(-w / 2f, w / 2f, 0f, t)
                3 -> hSeg(-w / 2f, w / 2f, h / 2f, t)
                5 -> vSeg(-w / 2f, -h / 2f, 0f, t)
                1 -> vSeg(w / 2f, -h / 2f, 0f, t)
                4 -> vSeg(-w / 2f, 0f, h / 2f, t)
                else -> vSeg(w / 2f, 0f, h / 2f, t)
            }
            if (lit) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3.5f
                paint.shader = null
                paint.color = k(0x40FF3A1A)
                c.drawPath(path, paint)
            }
            fill(if (lit) on else off)
            c.drawPath(path, paint)
        }
        c.restore()
    }

    private fun hSeg(x0: Float, x1: Float, y: Float, t: Float) {
        path.moveTo(x0 + t * 0.6f, y)
        path.lineTo(x0 + t * 1.1f, y - t / 2f)
        path.lineTo(x1 - t * 1.1f, y - t / 2f)
        path.lineTo(x1 - t * 0.6f, y)
        path.lineTo(x1 - t * 1.1f, y + t / 2f)
        path.lineTo(x0 + t * 1.1f, y + t / 2f)
        path.close()
    }

    private fun vSeg(x: Float, y0: Float, y1: Float, t: Float) {
        path.moveTo(x, y0 + t * 0.6f)
        path.lineTo(x + t / 2f, y0 + t * 1.1f)
        path.lineTo(x + t / 2f, y1 - t * 1.1f)
        path.lineTo(x, y1 - t * 0.6f)
        path.lineTo(x - t / 2f, y1 - t * 1.1f)
        path.lineTo(x - t / 2f, y0 + t * 1.1f)
        path.close()
    }

    private fun drawDisplay(c: Canvas, l: Lay) {
        var s = ctl.display()
        if (s.length > 3) s = s.substring(0, 3)
        while (s.length < 3) s += " "
        val on = k(0xFFFF3B1F)
        val off = k(0xFF3A100C)
        c.save()
        c.translate(l.dispX, l.dispY)
        c.scale(l.dispS, l.dispS)
        for (n in 0 until 3) drawSeg(c, glyph(s[n]), (n - 1) * 27f, 0f, on, off)
        c.restore()
    }

    private fun knobIndicator(c: Canvas, cx: Float, cy: Float, s: Float, v: Float, marker: Float) {
        c.save()
        c.translate(cx, cy)
        c.scale(s, s)
        val a = (-135.0 + 270.0 * v) * PI / 180.0
        val sa = sin(a).toFloat()
        val ca = cos(a).toFloat()
        paint.style = Paint.Style.STROKE
        paint.shader = null
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeWidth = 3.8f
        paint.color = k(0xFFF2F2F2)
        c.drawLine(5f * sa, -5f * ca, 30f * sa, -30f * ca, paint)
        paint.strokeCap = Paint.Cap.BUTT
        if (marker >= 0f) {
            val m = (-135.0 + 270.0 * marker) * PI / 180.0
            paint.strokeWidth = 2.4f
            paint.color = k(0xFFFF6A3D)
            c.drawCircle(61f * sin(m).toFloat(), -61f * cos(m).toFloat(), 5f, paint)
        }
        paint.style = Paint.Style.FILL
        c.restore()
    }

    private fun keyCap(c: Canvas, x: Float, y: Float, hw: Float, hh: Float, dark: Boolean, pressed: Boolean, led: Int) {
        val off = if (pressed) 2.5f else 0f
        val body = if (dark) k(0xFF8E8E8E) else k(0xFFD6D6D6)
        val hi = if (dark) k(0xFFA6A6A6) else k(0xFFEFEFEF)
        val lo = if (dark) k(0xFF747474) else k(0xFFBBBBBB)
        rr(c, x - hw - 2f, y - hh - 2f + off, x + hw + 2f, y + hh + 2f + off, 8f, k(0xFF111111))
        rr(c, x - hw, y - hh + off, x + hw, y + hh + off, 6f, if (pressed) mix(body, Color.BLACK, 0.12f) else body)
        rr(c, x - hw + 4f, y - hh + 3f + off, x + hw - 4f, y - hh + 11f + off, 4f, hi)
        rr(c, x - hw + 3f, y + hh - 9f + off, x + hw - 3f, y + hh - 2f + off, 4f, lo)
        rr(c, x - hw + 9f, y - hh + 14f + off, x + hw - 9f, y + hh - 12f + off, 5f, mix(body, hi, 0.45f))
        val idle = if (dark) k(0xFF5E5E5E) else k(0xFF8A8A8A)
        val col = when (led) {
            1 -> k(0xFFB5502C)
            2 -> k(0xFFFF6A3D)
            3 -> k(0xFFFFF0C2)
            4 -> k(0xFFB4B4B4)
            else -> idle
        }
        val sx0 = x - 6f
        val sy0 = y - hh + 4f + off
        if (led >= 2) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 5f
            paint.shader = null
            paint.color = k(0x44FF6A3D)
            rect.set(sx0 - 1f, sy0 - 1f, sx0 + 13f, sy0 + 21f)
            c.drawRoundRect(rect, 3f, 3f, paint)
        }
        rr(c, sx0, sy0, sx0 + 12f, sy0 + 19f, 2.5f, col)
    }

    /** Orientation toggle: shows the layout you will switch TO, plus a rotation arrow. */
    private fun drawRot(c: Canvas, l: Lay) {
        val x = l.rotX
        val y = l.rotY
        val r = l.rotR
        circ(c, x, y, r, k(0xFF2B2B2B))
        paint.style = Paint.Style.STROKE
        paint.shader = null
        paint.strokeWidth = 1.8f
        paint.color = k(0xFFD0D0D0)
        c.drawCircle(x, y, r, paint)
        val hw = if (l.portrait) r * 0.42f else r * 0.24f
        val hh = if (l.portrait) r * 0.24f else r * 0.42f
        rect.set(x - hw, y - hh, x + hw, y + hh)
        c.drawRoundRect(rect, 2.5f, 2.5f, paint)
        val rad = r * 0.76f
        rect.set(x - rad, y - rad, x + rad, y + rad)
        paint.strokeWidth = 1.6f
        c.drawArc(rect, 200f, 215f, false, paint)
        val a = Math.toRadians(55.0)
        val px = x + rad * cos(a).toFloat()
        val py = y + rad * sin(a).toFloat()
        val tx = -sin(a).toFloat()
        val ty = cos(a).toFloat()
        val nx = cos(a).toFloat()
        val ny = sin(a).toFloat()
        path.reset()
        path.moveTo(px + tx * 5f, py + ty * 5f)
        path.lineTo(px + nx * 4f, py + ny * 4f)
        path.lineTo(px - nx * 4f, py - ny * 4f)
        path.close()
        fill(k(0xFFD0D0D0))
        c.drawPath(path, paint)
    }

    private fun drawDynamic(c: Canvas) {
        val l = lay
        val pot = ctl.st.v[S.POT_CATCH] == 1
        // knob indicators + catch markers + level LEDs
        for (i in 0 until 7) {
            val mL = if (pot && !ctl.caughtL[i]) ctl.e.kit.level[i] else -1f
            val mP = if (pot && !ctl.caughtP[i]) ctl.storedParam(i) else -1f
            knobIndicator(c, l.lvX[i], l.lvY[i], l.ks, ctl.physL[i], mL)
            knobIndicator(c, l.paX[i], l.paY[i], l.ks, ctl.physP[i], mP)
            val lit = ctl.levelLed(i)
            if (lit > 0.04f) {
                val a = (60 + 195 * lit).toInt().coerceIn(0, 255)
                val ly = l.lvY[i] + l.ledDy
                circ(c, l.lvX[i], ly, 15f, Color.argb(a / 4, 255, 40, 40))
                circ(c, l.lvX[i], ly, 10f, Color.argb(a, 255, 50, 45))
                circ(c, l.lvX[i], l.lvY[i] + 38f * l.ks, 8f, Color.argb(a / 3, 255, 60, 50))
            }
        }
        knobIndicator(c, l.volX, l.volY, l.ks2, ctl.e.volume, -1f)
        val ea = encAngle.toDouble()
        circ(c, l.encX + 24f * l.ks2 * sin(ea).toFloat(), l.encY - 24f * l.ks2 * cos(ea).toFloat(), 3.4f, k(0xFF5C5C5C))

        // function buttons
        val pad = k(0xFF707070)
        val padHi = k(0xFF838383)
        val ledc = k(0xFFFF6B6B)
        val ph = l.padH
        for (id in 0 until 20) {
            val x = l.fx[id]
            val y = l.fy[id]
            val lit = ctl.btnLed(id)
            val off = if (ctl.held[id]) 1.6f else 0f
            val base = if (lit > 0f) mix(pad, ledc, 0.25f + 0.75f * lit) else pad
            val inner = if (lit > 0f) mix(padHi, ledc, 0.25f + 0.75f * lit) else padHi
            if (lit > 0.4f) circ(c, x, y, ph * 1.6f, Color.argb(55, 255, 90, 90))
            rr(c, x - ph, y - ph + off, x + ph, y + ph + off, 3.5f, base)
            rr(c, x - ph + 4f, y - ph + 4f + off, x + ph - 4f, y + ph - 4f + off, 2.5f, inner)
        }

        // transport keys
        for (n in 0 until 3) {
            val id = 20 + n
            val lit = ctl.btnLed(id) > 0.5f
            keyCap(c, l.trX[n], l.trY[n], l.trH, l.trH, false, ctl.held[id], if (lit) 2 else 0)
        }

        // step keys
        for (i in 0 until 16) {
            val dark = (i / 4) % 2 == 0
            keyCap(c, l.stX[i], l.stY[i], l.stHw, l.stHh, dark, ctl.heldStep[i], ctl.stepLed(i))
        }

        drawDisplay(c, l)

        // latch LED (tap the frog to toggle): single-finger mode for the hold-combinations
        circ(c, l.frogX, l.frogY + 66f * l.frogS, 6f * l.frogS.coerceAtLeast(0.9f), if (latch) k(0xFFFF6A3D) else k(0xFF8A8A8A))

        drawRot(c, l)
    }

    // ------------------------------------------------------------------ view plumbing

    private fun cancelAll() {
        for (p in ptrs.values) {
            if (p.kind == K_BTN || p.kind == K_STEP) sendUp(p.kind, p.id)
        }
        ptrs.clear()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        cancelAll()
        lay = if (h > w) portrait else landscape
        val l = lay
        sc = min(w / (l.dw + l.margin), h / (l.dh + l.margin))
        offX = (w - l.dw * sc) / 2f
        offY = (h - l.dh * sc) / 2f
        val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        c.translate(offX, offY)
        c.scale(sc, sc)
        c.translate(-l.ox, -l.oy)
        drawStatic(c, l)
        bmp = b
    }

    override fun onDraw(canvas: Canvas) {
        ctl.tick()
        val b = bmp
        if (b != null) canvas.drawBitmap(b, 0f, 0f, null)
        canvas.save()
        canvas.translate(offX, offY)
        canvas.scale(sc, sc)
        canvas.translate(-lay.ox, -lay.oy)
        drawDynamic(canvas)
        canvas.restore()
        postInvalidateDelayed(33L)
    }

    // ------------------------------------------------------------------ touch

    private fun hit(dx: Float, dy: Float): Int {
        val l = lay
        if (hypot(dx - l.rotX, dy - l.rotY) <= l.rotR + 8f) return K_ROT * 100
        for (i in 0 until 16) {
            if (abs(dx - l.stX[i]) <= l.stHw + 8f && abs(dy - l.stY[i]) <= l.stHh + 7f) return K_STEP * 100 + i
        }
        for (n in 0 until 3) {
            if (abs(dx - l.trX[n]) <= l.trH + 5f && abs(dy - l.trY[n]) <= l.trH + 5f) return K_BTN * 100 + 20 + n
        }
        for (id in 0 until 20) {
            if (abs(dx - l.fx[id]) <= l.fHitW && abs(dy - l.fy[id]) <= l.fHitH) return K_BTN * 100 + id
        }
        for (i in 0 until 7) {
            if (hypot(dx - l.lvX[i], dy - l.lvY[i]) <= l.knobHit) return K_LEVEL * 100 + i
            if (hypot(dx - l.paX[i], dy - l.paY[i]) <= l.knobHit) return K_PARAM * 100 + i
        }
        if (hypot(dx - l.volX, dy - l.volY) <= l.knobHit) return K_VOL * 100
        if (hypot(dx - l.encX, dy - l.encY) <= l.knobHit - 4f) return K_ENC * 100
        if (hypot(dx - l.frogX, dy - l.frogY) <= 90f * l.frogS) return K_FROG * 100
        return -1
    }

    private fun sendDown(kind: Int, id: Int) {
        if (kind == K_STEP) ctl.stepDown(id) else ctl.buttonDown(id)
    }

    private fun sendUp(kind: Int, id: Int) {
        if (kind == K_STEP) ctl.stepUp(id) else ctl.buttonUp(id)
    }

    private fun releaseLatched() {
        for (key in latched) sendUp(key / 100, key % 100)
        latched.clear()
    }

    private fun down(pid: Int, x: Float, y: Float) {
        val dx = (x - offX) / sc + lay.ox
        val dy = (y - offY) / sc + lay.oy
        val h = hit(dx, dy)
        if (h < 0) return
        val kind = h / 100
        val id = h % 100
        val now = System.currentTimeMillis()
        if (kind == K_BTN || kind == K_STEP) {
            val key = kind * 100 + id
            if (latch && latched.contains(key)) {
                latched.remove(key)
                sendUp(kind, id)
                ptrs[pid] = Ptr(K_NONE, 0, now, x, y)
                return
            }
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            sendDown(kind, id)
        }
        ptrs[pid] = Ptr(kind, id, now, x, y)
    }

    private fun move(pid: Int, x: Float, y: Float) {
        val p = ptrs[pid] ?: return
        val ddx = (x - p.lx) / sc
        val ddy = (y - p.ly) / sc
        p.lx = x
        p.ly = y
        p.moved += abs(ddx) + abs(ddy)
        when (p.kind) {
            K_PARAM -> ctl.paramMove(p.id, (ctl.physP[p.id] - ddy / 170f).coerceIn(0f, 1f))
            K_LEVEL -> ctl.levelMove(p.id, (ctl.physL[p.id] - ddy / 170f).coerceIn(0f, 1f))
            K_VOL -> ctl.volumeMove((ctl.e.volume - ddy / 170f).coerceIn(0f, 1f))
            K_ENC -> {
                p.acc += -ddy + ddx
                while (p.acc >= 16f) { p.acc -= 16f; ctl.encoderTurn(1); encAngle += 0.25f }
                while (p.acc <= -16f) { p.acc += 16f; ctl.encoderTurn(-1); encAngle -= 0.25f }
            }
        }
    }

    private fun up(pid: Int) {
        val p = ptrs.remove(pid) ?: return
        val now = System.currentTimeMillis()
        val dur = now - p.t0
        when (p.kind) {
            K_BTN, K_STEP -> {
                val key = p.kind * 100 + p.id
                val latchable = !(p.kind == K_BTN && (p.id == B.PLAY || p.id == B.STOP))
                if (latch && latchable && dur > 350L && p.moved < 30f) latched.add(key)
                else sendUp(p.kind, p.id)
            }
            K_ENC -> if (p.moved < 14f) ctl.encoderLong(dur)
            K_FROG -> if (p.moved < 20f && dur < 500L) {
                latch = !latch
                if (!latch) releaseLatched()
            }
            K_ROT -> if (p.moved < 25f && dur < 700L) {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onToggleOrientation?.invoke()
            }
        }
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = ev.actionIndex
                down(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_MOVE -> {
                for (i in 0 until ev.pointerCount) move(ev.getPointerId(i), ev.getX(i), ev.getY(i))
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> {
                up(ev.getPointerId(ev.actionIndex))
            }
            MotionEvent.ACTION_CANCEL -> {
                val ids = ArrayList<Int>(ptrs.keys)
                for (id in ids) up(id)
            }
        }
        return true
    }
}
